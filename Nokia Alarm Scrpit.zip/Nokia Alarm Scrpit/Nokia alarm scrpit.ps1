﻿Set-Location -Path $PSScriptRoot
$InputFilePath = Read-Host "enter file name"
$TemplateFilePath = "TEMPLATE.xml"
$OutputFilePath = "Modified_$InputFilePath"
$LookupClass = "com.nokia.srbts:MRBTS"
$LookupClassOutput = "com.nokia.srbts.eqm:SMOD"

[xml]$xmlData = Get-Content -Path $InputFilePath
[xml]$xmlTemp = Get-Content -Path $TemplateFilePath

$ManagedObjectInfo = $xmlData.raml.cmData.managedObject | Where {$_.class -eq $LookupClass}
$DistName = $ManagedObjectInfo.distName
$Version = $ManagedObjectInfo.version
$nodes = $xmlData.ImportNode($xmlTemp.get_DocumentElement(), $true)
$PreviousNode = $xmlData.raml.cmData.managedObject | Where {$_.class -eq $LookupClassOutput}

foreach($node in $nodes.cmData.managedObject) {
    $node.distName = $node.distName.Replace("chagedistName", "$DistName")
    $node.version = $Version
    $xmlData.raml.cmData.InsertAfter($node, $PreviousNode)
    $PreviousNode = $node
}

Set-content -value $xmlData.InnerXml -Path $OutputFilePath